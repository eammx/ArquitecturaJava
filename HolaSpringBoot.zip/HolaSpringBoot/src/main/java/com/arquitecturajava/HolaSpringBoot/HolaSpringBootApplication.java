package com.arquitecturajava.HolaSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HolaSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(HolaSpringBootApplication.class, args);
	}

}
